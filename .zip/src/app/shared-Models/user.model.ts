export  interface userDetails {
  email: String;
  password: String;
}
