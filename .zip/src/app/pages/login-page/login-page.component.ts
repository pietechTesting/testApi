import { Component, OnInit } from '@angular/core';
import { userDetails } from '../../shared-Models/user.model';
import { LoginService} from '../../services/login.service'
@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css'],
  providers: [LoginService]
})
export class LoginPageComponent implements OnInit {
  loginForm = true;
  registrationForm = false;

  public userInfo: userDetails[] = []
  public userCradentials: userDetails = {
    email: '',
    password: '',
  };
  RegisterHere() {
    this.loginForm = false;
    this.registrationForm = true;
  }
  onSubmit() {
    this.logService.login(this.userCradentials).subscribe((loginCreds) => {
      console.log('login success ' + JSON.stringify(loginCreds));
    }, (error) => {
      console.log('error' + JSON.stringify(error));
    });
  }
  onRegister() {
    console.log('on register ' + JSON.stringify(this.userCradentials));
  }
  constructor(public logService: LoginService) {

  }

  ngOnInit() {
  }

}
