import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {ConstantService} from '../services/constant.service';
@Injectable()
export class LoginService {
   // private header = new HttpHeaders();


  constructor(private http: HttpClient, private constService: ConstantService  ) { }
  login(loginData) {
    const body = loginData;
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.post(this.constService.Login_Auth + 'auth/local', body, {
      headers: headers
    });
  }

}
