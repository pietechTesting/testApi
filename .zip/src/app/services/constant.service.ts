import {Injectable} from '@angular/core';

@Injectable()
export class ConstantService {
  API_ENDPOINT: String;
  Login_Auth: String;

  constructor() {
    this.Login_Auth = 'http://192.168.1.17:9000/'; // 'https://restaurantrestapi.herokuapp.com/';//
    this.API_ENDPOINT = 'http://192.168.1.17:9000/api/'; // 'https://restaurantrestapi.herokuapp.com/api/';//
  }

}
